import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Request, Response, HTTPException
from fastapi.responses import RedirectResponse
from config import settings
from auth.models import (
    SignupRequest, OTPVerifyRequest, LoginRequest, SetPasswordRequest,
    ForgotPasswordRequest, ResetPasswordRequest, MessageResponse,
)
from auth.utils import hash_password, verify_password, generate_otp, is_otp_expired, generate_session_token
from auth.email_service import send_otp_email, send_password_reset_email
from auth.google_oauth import get_google_redirect_url, handle_google_callback
from core.db import (
    create_pending_signup, get_pending_signup, delete_pending_signup,
    create_user, get_user_by_email, create_session, get_session,
    delete_session, get_user_by_id, update_user_password, update_user_auth_provider,
    create_password_reset, get_password_reset, delete_password_reset, delete_password_resets_for_email,
)

router = APIRouter(prefix="/auth", tags=["auth"])


# ============================================================
# Rate limiting
# ------------------------------------------------------------
# Simple in-memory sliding-window limiter, keyed by (bucket name + IP).
# Isse brute-force login attempts aur forgot-password email-spam dono
# rukte hain. NOTE: single-process ke liye theek hai — agar kabhi
# multiple server instances (load balancer ke peeche) pe deploy karo,
# isko Redis jaisa shared store use karna padega, kyunki har process
# ka apna alag in-memory dict hoga.
# ============================================================

_rate_limit_buckets: dict[str, list[float]] = defaultdict(list)


def _check_rate_limit(request: Request, bucket_name: str, max_attempts: int = 5, window_seconds: int = 60):
    ip = request.client.host if request.client else "unknown"
    key = f"{bucket_name}:{ip}"
    now = time.time()
    bucket = _rate_limit_buckets[key]

    while bucket and bucket[0] < now - window_seconds:
        bucket.pop(0)

    if len(bucket) >= max_attempts:
        raise HTTPException(status_code=429, detail="Too many attempts. Please wait a bit and try again.")

    bucket.append(now)


def _set_session_cookie(request: Request, response: Response, user_id: int):
    session_id = generate_session_token()
    expires_at = (datetime.now(timezone.utc) + timedelta(seconds=settings.SESSION_MAX_AGE)).isoformat()
    create_session(session_id, user_id, expires_at)
    response.set_cookie(
        settings.SESSION_COOKIE_NAME,
        session_id,
        max_age=settings.SESSION_MAX_AGE,
        httponly=True,
        samesite="lax",
        # Production (HTTPS) mein cookie sirf HTTPS pe bhejta hai. Local
        # dev (http://127.0.0.1) mein request.url.scheme "http" hoga,
        # isliye wahan flag apne aap False rahega — koi manual config
        # switch nahi chahiye.
        secure=request.url.scheme == "https",
    )


# ---------- Signup + OTP ----------

@router.post("/signup", response_model=MessageResponse)
def signup(data: SignupRequest, request: Request):
    _check_rate_limit(request, "signup", max_attempts=5, window_seconds=300)

    if get_user_by_email(data.email):
        raise HTTPException(400, "This email is already registered")

    password_hash = hash_password(data.password)
    otp = generate_otp()
    create_pending_signup(data.email, data.name, data.username, password_hash, otp)

    sent = send_otp_email(data.email, otp)
    if not sent:
        raise HTTPException(500, "There was a problem sending the OTP email. Please try again")

    return MessageResponse(status="ok", message="OTP has been sent. Please check your email")


@router.post("/verify-otp", response_model=MessageResponse)
def verify_otp(data: OTPVerifyRequest):
    pending = get_pending_signup(data.email)
    if not pending:
        raise HTTPException(400, "No pending signup was found for this email address")

    if is_otp_expired(pending["otp_created_at"]):
        delete_pending_signup(data.email)
        raise HTTPException(400, "The OTP has expired. Please sign up again")

    if pending["otp"] != data.otp:
        raise HTTPException(400, "Wrong OTP")

    create_user(
        name=pending["name"], email=data.email, username=pending["username"],
        password_hash=pending["password_hash"], auth_provider="password", is_verified=1,
    )
    delete_pending_signup(data.email)

    return MessageResponse(status="ok", message="Account created successfully. Please log in")


# ---------- Login / Logout ----------

@router.post("/login", response_model=MessageResponse)
def login(data: LoginRequest, request: Request, response: Response):
    _check_rate_limit(request, "login", max_attempts=5, window_seconds=60)

    user = get_user_by_email(data.email)
    if not user or not user["password_hash"]:
        raise HTTPException(401, "Incorrect email or password")

    if not verify_password(data.password, user["password_hash"]):
        raise HTTPException(401, "Incorrect email or password")

    _set_session_cookie(request, response, user["id"])
    return MessageResponse(status="ok", message="Login successful")


@router.post("/logout", response_model=MessageResponse)
def logout(request: Request, response: Response):
    session_id = request.cookies.get(settings.SESSION_COOKIE_NAME)
    if session_id and session_id != "guest":
        delete_session(session_id)
    response.delete_cookie(settings.SESSION_COOKIE_NAME)
    return MessageResponse(status="ok", message="You have been logged out successfully")


# ---------- Guest ----------

@router.post("/guest-login", response_model=MessageResponse)
def guest_login(request: Request, response: Response):
    response.set_cookie(
        settings.SESSION_COOKIE_NAME,
        "guest",
        httponly=True,
        samesite="lax",
        secure=request.url.scheme == "https",
    )
    return MessageResponse(status="ok", message="Guest mode active")


# ---------- Google OAuth ----------

@router.get("/google/login")
async def google_login(request: Request):
    return await get_google_redirect_url(request)


@router.get("/google/callback")
async def google_callback(request: Request):
    try:
        user = await handle_google_callback(request)
    except Exception as e:
        # Internal exception detail (library internals, config hints)
        # client ko kabhi nahi dikhna chahiye — server logs mein rakho,
        # user ko sirf generic message do.
        print(f"[auth] Google login failed: {e}")
        raise HTTPException(400, "Google login failed. Please try again.")

    # IMPORTANT: cookie must be set on the redirect response itself.
    # Setting it on an injected `response: Response` param only merges
    # into the final response when you return a plain dict — it does
    # NOT merge when you return a RedirectResponse instance directly.
    redirect = RedirectResponse(url="/dashboard")
    _set_session_cookie(request, redirect, user["id"])
    return redirect


# ---------- Add Password (for Google-only accounts) ----------

@router.post("/set-password", response_model=MessageResponse)
def set_password(data: SetPasswordRequest, request: Request):
    """
    Jo user Google se signup kiya tha (password_hash NULL), unhe ab
    email+password se bhi login karne laayak banata hai. Already
    password-wale accounts ke liye blocked.
    """
    user = get_current_user(request)
    if not user or user.get("guest"):
        raise HTTPException(401, "Login required")

    if user.get("password_hash"):
        raise HTTPException(400, "This account already has a password set")

    password_hash = hash_password(data.password)
    update_user_password(user["email"], password_hash)

    if user["auth_provider"] == "google":
        update_user_auth_provider(user["email"], "both")

    return MessageResponse(status="ok", message="Password added successfully. You can now also log in with your email and password")


# ---------- Forgot Password (link-based, 1hr expiry) ----------

@router.post("/forgot-password", response_model=MessageResponse)
def forgot_password(data: ForgotPasswordRequest, request: Request):
    """
    Email se reset link bhejta hai. Response HAMESHA generic hai —
    chahe account exist kare ya na kare (user enumeration se bachne
    ke liye). Rate-limited taaki koi ek email pe baar-baar mail spam
    na kar sake.
    """
    _check_rate_limit(request, "forgot-password", max_attempts=3, window_seconds=300)

    generic = MessageResponse(
        status="ok",
        message="If an account exists for that email, a password reset link has been sent.",
    )

    user = get_user_by_email(data.email)
    if not user:
        return generic

    delete_password_resets_for_email(data.email)

    token = generate_session_token()
    expires_at = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    create_password_reset(token, data.email, expires_at)

    reset_link = f"{str(request.base_url).rstrip('/')}/reset-password?token={token}"
    send_password_reset_email(data.email, reset_link)

    return generic


@router.post("/reset-password", response_model=MessageResponse)
def reset_password(data: ResetPasswordRequest):
    reset = get_password_reset(data.token)
    if not reset:
        raise HTTPException(400, "This reset link is invalid or has already been used")

    if datetime.fromisoformat(reset["expires_at"]) < datetime.now(timezone.utc):
        delete_password_reset(data.token)
        raise HTTPException(400, "This reset link has expired. Please request a new one")

    password_hash = hash_password(data.password)
    update_user_password(reset["email"], password_hash)
    delete_password_reset(data.token)

    return MessageResponse(status="ok", message="Password reset successfully. Please log in with your new password")


# ---------- Current user helper (dusre routes ke liye) ----------

def get_current_user(request: Request):
    session_id = request.cookies.get(settings.SESSION_COOKIE_NAME)
    if not session_id:
        return None
    if session_id == "guest":
        return {"guest": True}

    session = get_session(session_id)
    if not session:
        return None

    if datetime.fromisoformat(session["expires_at"]) < datetime.now(timezone.utc):
        delete_session(session_id)
        return None

    return get_user_by_id(session["user_id"])