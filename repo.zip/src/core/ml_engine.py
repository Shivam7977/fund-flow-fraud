import os
import re
import json
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from config import settings
from core.explain_labels import describe_feature

# ---------- Load once, at import time ----------

with open(os.path.join(settings.MODELS_DIR, "ensemble_config.json")) as f:
    CONFIG = json.load(f)

WEIGHTS = CONFIG["weights"]
THRESHOLDS = CONFIG["thresholds"]
FEATURES_XGB2 = CONFIG["features"]["xgboost_v2"]      # 30 features, in training order
FEATURES_EXP3 = CONFIG["features"]["xgboost_exp3"]     # 28 features, in training order
ISO_MIN = CONFIG["iso_normalization"]["min"]
ISO_MAX = CONFIG["iso_normalization"]["max"]

iso_forest = joblib.load(os.path.join(settings.MODELS_DIR, "iso_compatible.joblib"))

xgb_v2 = xgb.XGBClassifier()
xgb_v2.load_model(os.path.join(settings.MODELS_DIR, "xgb_v2_compatible.json"))

xgb_exp3 = xgb.XGBClassifier()
xgb_exp3.load_model(os.path.join(settings.MODELS_DIR, "xgb_exp3_compatible.json"))

# Account types: 70 MB JSON dict RAM mein ~300MB+ leta tha (Render free = 512MB).
# Ab compact format: sirf NON-savings accounts, sorted int array + searchsorted.
# "savings" pehle se default tha (.get(..., "savings")), isliye behavior same hai.
# Banane ke liye: python scripts/compact_account_map.py
_ACCT_ID_RE = re.compile(r"^([CM])(\d+)$")
_acct_npz = np.load(settings.ACCOUNT_TYPE_NPZ_PATH, allow_pickle=False)
_ACCT_KEYS = _acct_npz["keys"]                      # sorted int64
_ACCT_VALS = _acct_npz["vals"]                      # uint8 index -> _ACCT_TYPE_NAMES
_ACCT_TYPE_NAMES = [str(t) for t in _acct_npz["type_names"]]
with open(settings.ACCOUNT_TYPE_EXTRAS_PATH) as f:
    _ACCT_EXTRAS = json.load(f)                     # non-standard IDs (chhota)


def _lookup_account_type(account_id: str) -> str:
    if account_id in _ACCT_EXTRAS:
        return _ACCT_EXTRAS[account_id]
    m = _ACCT_ID_RE.match(account_id)
    if not m or str(int(m.group(2))) != m.group(2):
        return "savings"
    key = int(m.group(2)) * 2 + (1 if m.group(1) == "M" else 0)
    i = int(np.searchsorted(_ACCT_KEYS, key))
    if i < len(_ACCT_KEYS) and _ACCT_KEYS[i] == key:
        return _ACCT_TYPE_NAMES[int(_ACCT_VALS[i])]
    return "savings"

TYPE_COLUMNS = ["type_ATM_WITHDRAWAL", "type_CASH_DEPOSIT", "type_NACH", "type_NEFT", "type_UPI"]
ACCT_COLUMNS = ["acct_business", "acct_current", "acct_jan_dhan", "acct_savings", "acct_student"]
VALID_ACCOUNT_TYPES = {"business", "current", "jan_dhan", "savings", "student"}

RBI_STRUCTURING_MIN = 40000
RBI_STRUCTURING_MAX = 49999
RBI_CTR_THRESHOLD = 1000000
RBI_RTGS_MIN = 200000

# Explanation settings
TOP_N_REASONS = 5          # UI mein kitne top features dikhane hain
MIN_SHAP_ABS = 1e-6        # isse chhota contribution "zero" maan ke skip karo


# ---------- Feature building ----------

def _get_account_type(account_id: str, override: str | None = None) -> str:
    """
    Static graph se aaya account, toh uska real type map mein milega.
    Naya/unknown account → 'savings' default (India mein sabse common type,
    isliye least-biased guess).

    `override` — agar caller (single-transaction /predict check) ne
    explicitly account_type diya hai, wahi priority se use hoga. Isse
    CSV/batch path par koi asar nahi padta, wahan ye kabhi set hi nahi
    hota, so behavior bilkul pehle jaisa rehta hai.
    """
    if override and override in VALID_ACCOUNT_TYPES:
        return override
    return _lookup_account_type(account_id)



def build_features(txn: dict, batch_history: list = None) -> pd.DataFrame:
    """
    txn expected keys:
      nameOrig, nameDest, amount_inr, oldbalance_inr, newbalance_inr,
      hour (0-23), day_of_week (0-6), txn_type (one of ATM_WITHDRAWAL/
      CASH_DEPOSIT/NACH/NEFT/UPI)

    Optional key:
      account_type — manual override (business/current/jan_dhan/savings/
      student). Only used if present; otherwise the sender's account
      type is looked up from the static ACCOUNT_TYPE_MAP as before.

    batch_history = optional list of transactions processed earlier in
    the same /predict-batch request (currently unused here — graph_engine.py
    uses it for pattern detection; kept as a param for API consistency).
    """
    amount_inr = float(txn["amount_inr"])
    oldbalance_inr = float(txn["oldbalance_inr"])
    newbalance_inr = float(txn["newbalance_inr"])
    hour = int(txn["hour"])
    day_of_week = int(txn["day_of_week"])
    txn_type = txn["txn_type"]

    row = {}

    # Time features
    row["hour"] = hour
    row["day_of_week"] = day_of_week
    row["is_weekend"] = int(day_of_week in [5, 6])
    row["is_odd_hour"] = int(hour in range(0, 6))

    # Amount features
    row["amount_inr"] = amount_inr
    row["amount_log"] = np.log1p(amount_inr)
    if oldbalance_inr <= 0:
        row["amount_to_balance"] = -1
    else:
        row["amount_to_balance"] = round(min(amount_inr / oldbalance_inr, 2.0), 4)
    row["balance_after_zero"] = int(newbalance_inr == 0)

    # Balance features
    row["oldbalance_inr"] = oldbalance_inr
    row["newbalance_inr"] = newbalance_inr
    # Training mein raw PaySim units (amount, oldbalanceOrg, newbalanceOrig) se bana tha.
    # Naya input hamesha INR context mein aayega, isliye INR values pe hi mismatch check.
    balance_mismatch = abs((oldbalance_inr - amount_inr) - newbalance_inr)
    row["balance_mismatch"] = round(balance_mismatch, 2)
    row["has_mismatch"] = int(balance_mismatch > 0.01)

    # RBI threshold features
    row["is_structuring"] = int(RBI_STRUCTURING_MIN <= amount_inr <= RBI_STRUCTURING_MAX)
    row["is_ctr_threshold"] = int(amount_inr >= RBI_CTR_THRESHOLD)
    row["is_rtgs_range"] = int(amount_inr >= RBI_RTGS_MIN)

    # NOTE: Velocity features (sender/receiver_txn_count, total_amount) removed
    # from here — retrain ke baad ensemble_config.json ke feature-list se hi
    # hata diye gaye the (SHAP investigation mein future-info leakage nikla
    # tha), isliye inhe yahan compute karna sirf 2 bekaar get_account_history()
    # DB calls tha har prediction mein, jinka result kabhi use hi nahi hota tha.

    # One-hot: transaction type
    for col in TYPE_COLUMNS:
        row[col] = 0
    row[f"type_{txn_type}"] = 1

    # One-hot: account type (of the sender)
    account_type = _get_account_type(txn["nameOrig"], txn.get("account_type"))
    for col in ACCT_COLUMNS:
        row[col] = 0
    row[f"acct_{account_type}"] = 1

    # Domain feature: profile mismatch
    row["is_profile_mismatch"] = int(
        account_type in ["student", "jan_dhan"] and row["is_rtgs_range"] == 1
    )

    return pd.DataFrame([row])


# ---------- Explanation (SHAP) ----------

def _xgb_contribs(model, X: pd.DataFrame) -> pd.Series:
    """
    XGBoost ka built-in TreeSHAP (pred_contribs=True) — exact SHAP values,
    `shap` library install kiye bina (Render pe light rehta hai).
    Values log-odds space mein hoti hain. Last column bias (base value) hoti
    hai, wo kisi feature ki nahi, isliye hata dete hain.
    """
    raw = model.get_booster().predict(xgb.DMatrix(X), pred_contribs=True)
    return pd.Series(raw[0][:-1], index=X.columns)


def explain_features(features_full: pd.DataFrame) -> dict:
    """
    Ensemble ke XGBoost hisse (V2 + Exp3) ka weighted SHAP explanation.
    Isolation Forest ko explain nahi karte (wo unsupervised anomaly score hai).

    Combine karna: dono models ki contributions ko unke ensemble weights se
    normalize karke jodte hain. Ye approximation hai (ensemble asli mein
    probability space mein blend hota hai), lekin "kaunse features ne score
    ko upar/neeche dhakela" ranking ke liye sahi kaam karta hai.
    """
    X_full = features_full[FEATURES_XGB2]
    X_exp3 = features_full[FEATURES_EXP3]

    c2 = _xgb_contribs(xgb_v2, X_full)
    c3 = _xgb_contribs(xgb_exp3, X_exp3)

    w_sum = WEIGHTS["xgboost_v2"] + WEIGHTS["xgboost_exp3"]
    w2 = WEIGHTS["xgboost_v2"] / w_sum
    w3 = WEIGHTS["xgboost_exp3"] / w_sum

    # Exp3 mein 2 features kam hain (type_UPI, has_mismatch) — unka c3 hissa 0
    combined = c2 * w2 + c3.reindex(c2.index, fill_value=0.0) * w3

    top = combined.reindex(combined.abs().sort_values(ascending=False).index)[:TOP_N_REASONS]

    row = features_full.iloc[0]
    items = []
    for name, shap_val in top.items():
        if abs(shap_val) < MIN_SHAP_ABS:
            continue
        value = float(row[name])
        items.append({
            "feature": name,
            "value": round(value, 4),
            "shap": round(float(shap_val), 4),
            "direction": "fraud" if shap_val > 0 else "normal",   # + = fraud ki taraf, - = normal ki taraf
            "reason": describe_feature(name, value),
        })

    return {
        "method": "TreeSHAP on XGBoost V2 + Exp3 (weighted)",
        "top_features": items,
    }


# ---------- Prediction ----------

def predict_ml(txn: dict, batch_history: list = None, explain: bool = False) -> dict:
    features_full = build_features(txn, batch_history)

    # XGBoost V2 + Isolation Forest — full 30-feature set, training order se
    X_full = features_full[FEATURES_XGB2]

    iso_raw = -iso_forest.decision_function(X_full)[0]   # higher = more suspicious
    iso_score_01 = (iso_raw - ISO_MIN) / (ISO_MAX - ISO_MIN)
    iso_score_01 = float(np.clip(iso_score_01, 0, 1))

    xgb2_score = float(xgb_v2.predict_proba(X_full)[0][1])

    # XGBoost Exp3 — 28-feature set (type_UPI + has_mismatch dropped)
    X_exp3 = features_full[FEATURES_EXP3]
    exp3_score = float(xgb_exp3.predict_proba(X_exp3)[0][1])

    ml_score = (
        WEIGHTS["isolation_forest"] * iso_score_01 +
        WEIGHTS["xgboost_v2"] * xgb2_score +
        WEIGHTS["xgboost_exp3"] * exp3_score
    )

    if ml_score >= THRESHOLDS["fraud"]:
        risk_level = "FRAUD"
    elif ml_score >= THRESHOLDS["review"]:
        risk_level = "REVIEW"
    else:
        risk_level = "NORMAL"

    result = {
        "ml_score": round(ml_score, 4),
        "iso_score": round(iso_score_01, 4),
        "xgb2_score": round(xgb2_score, 4),
        "exp3_score": round(exp3_score, 4),
        "risk_level": risk_level,
    }

    # Sirf jab caller maange — batch mein har row ke liye nahi chalana
    if explain:
        result["explanation"] = explain_features(features_full)

    return result